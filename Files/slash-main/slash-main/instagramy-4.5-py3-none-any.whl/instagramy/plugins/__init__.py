""" Various Plugins for instagramy """
